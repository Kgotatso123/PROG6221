﻿class Program
{

    static void Main(string[] args)
    {

        Recipe recipe = new Recipe();
        while (true)
        {
            Console.WriteLine("===================================");
            Console.WriteLine("Enter '1' to enter recipe details");
            Console.WriteLine("Enter '2' to display recipe");
            Console.WriteLine("Enter '3' to scale recipe");
            Console.WriteLine("Enter '4' to reset quantities");
            Console.WriteLine("Enter '5' to clear recipe");
            Console.WriteLine("Enter '6' to exit");
            Console.WriteLine("===================================");
            string ans = Console.ReadLine();
            Console.WriteLine("                                     ");
            switch (ans)
            {

                case "1":
                    recipe.DetailEntry();
                    break;
                case "2":
                    recipe.DisplayRecipe();
                    break;
                case "3":
                    Console.Write("Enter scaling factor (0.5, 2, or 3): ");
                    double scale1;
                    if (double.TryParse(Console.ReadLine(), out scale1))
                    {
                        recipe.ScaleRecipe(scale1);
                    }
                    else
                    {
                        Console.WriteLine("\n+Please Enter a valid number+\n");
                    }

                    break;
                case "4":
                    recipe.ResetQuantities();
                    break;
                case "5":
                    recipe.ClearRecipe();
                    break;
                case "6":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please enter a valid choice.");
                    break;
            }
        }
    }
}

class Recipe
{
    private string[] ingredients;
    private double[] amount;
    private string[] units;
    private string[] steps;

    public Recipe()
    {
        ingredients = new string[0];
        amount = new double[0];
        units = new string[0];
        steps = new string[0];

    }

    public void DetailEntry()
    {

        Console.Write("Enter the number of ingredients: ");

        int ingNum;
        if (int.TryParse(Console.ReadLine(), out ingNum))
        {

            ingredients = new string[ingNum];
            amount = new double[ingNum];
            units = new string[ingNum];


            for (int i = 0; i < ingNum; i++)
            {
                Console.WriteLine($"Enter details for ingredient #{i + 1}:");
                Console.Write("Name: ");
                ingredients[i] = Console.ReadLine();
                Console.Write("Quantity: ");
                amount[i] = double.Parse(Console.ReadLine());
                Console.Write("Unit of measurement: ");
                units[i] = Console.ReadLine();
            }


            Console.Write("Enter the number of steps: ");
            int Stnum = int.Parse(Console.ReadLine());


            steps = new string[Stnum];


            for (int i = 0; i < Stnum; i++)
            {
                Console.Write($"Enter step #{i + 1}: ");
                steps[i] = Console.ReadLine();
            }

        }
        else
        {
            Console.WriteLine("                                       ");
            Console.WriteLine("Please Enter a number+\n");

        }


    }

    public void DisplayRecipe()
    {

        Console.WriteLine("Ingredients:");
        for (int i = 0; i < ingredients.Length; i++)
        {
            Console.WriteLine($"- {amount[i]} {units[i]} of {ingredients[i]}");

        }


        Console.WriteLine("Steps:");
        for (int i = 0; i < steps.Length; i++)
        {
            Console.WriteLine($"- {steps[i]}");
        }
    }

    public void ScaleRecipe(double scale)
    {

        for (int i = 0; i < amount.Length; i++)
        {
            amount[i] *= scale;
        }
    }

    public void ResetQuantities()
    {
        for (int i = 0; i < amount.Length; i++)
        {
            amount[i] /= 2;
        }
    }

    public void ClearRecipe()
    {

        ingredients = new string[0];
        amount = new double[0];
        units = new string[0];
        steps = new string[0];
    }
}
